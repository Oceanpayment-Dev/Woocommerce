
const oceanboleto_settings = window.wc.wcSettings.getSetting( 'oceanboleto_data', {} );


const oceanboleto_label = window.wp.htmlEntities.decodeEntities( oceanboleto_settings.title ) || window.wp.i18n.__( 'Oceanpayment Boleto Payment Gateway', 'oceanpayment-boleto-gateway' );




const oceanboleto_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanboleto_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanboleto-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanboleto_Block_Gateway = {
    name: 'oceanboleto',

    label: React.createElement(I, {
        id: "oceanboleto",
        title: oceanboleto_settings.title,
        icons: oceanboleto_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanboleto_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanboleto_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanboleto_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-boleto-gateway' ),
  /*  supports: {
        features: oceanboleto_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanboleto_Block_Gateway );