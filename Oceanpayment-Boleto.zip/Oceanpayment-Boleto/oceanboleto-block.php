<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanboleto_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanboleto';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanboleto_settings', [] );
        $this->gateway = new WC_Gateway_Oceanboleto();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanboleto-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanboleto-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanboleto-blocks-integration');
            
        }


        return [ 'oceanboleto-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'boleto_icon',
            'alt' => 'Boleto',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_boleto.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>