
const oceanafterpay_settings = window.wc.wcSettings.getSetting( 'oceanafterpay_data', {} );


const oceanafterpay_label = window.wp.htmlEntities.decodeEntities( oceanafterpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment Afterpay Payment Gateway', 'oceanpayment-afterpay-gateway' );




const oceanafterpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanafterpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanafterpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanafterpay_Block_Gateway = {
    name: 'oceanafterpay',

    label: React.createElement(I, {
        id: "oceanafterpay",
        title: oceanafterpay_settings.title,
        icons: oceanafterpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanafterpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanafterpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanafterpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-afterpay-gateway' ),
  /*  supports: {
        features: oceanafterpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanafterpay_Block_Gateway );