
const oceanideal_settings = window.wc.wcSettings.getSetting( 'oceanideal_data', {} );


const oceanideal_label = window.wp.htmlEntities.decodeEntities( oceanideal_settings.title ) || window.wp.i18n.__( 'Oceanpayment iDEAL Payment Gateway', 'oceanpayment-ideal-gateway' );




const oceanideal_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanideal_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanideal-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanideal_Block_Gateway = {
    name: 'oceanideal',

    label: React.createElement(I, {
        id: "oceanideal",
        title: oceanideal_settings.title,
        icons: oceanideal_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanideal_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanideal_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanideal_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-ideal-gateway' ),
  /*  supports: {
        features: oceanideal_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanideal_Block_Gateway );