<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanideal_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanideal';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanideal_settings', [] );
        $this->gateway = new WC_Gateway_Oceanideal();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanideal-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanideal-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanideal-blocks-integration');
            
        }


        return [ 'oceanideal-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'ideal_icon',
            'alt' => 'ideal',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_iDEAL.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>