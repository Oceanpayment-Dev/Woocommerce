<?php
/*
	Plugin Name: Oceanpayment MyBank Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment MyBank Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-mybank-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanmybank', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanmybank_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanmybank_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanmybank.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanmybank_add_gateway' );

} // End woocommerce_oceanmybank_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanmybank_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanmybank';
	return $methods;
} // End woocommerce_oceanmybank_add_gateway()