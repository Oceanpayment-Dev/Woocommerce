=== Oceanpayment AliPay Gateway ===
Contributors: oceanpayment
Tags: payment
Requires at least: 4.0
Tested up to: 6.1
Stable tag: 6.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

oceanpayment AliPay payment  plugin

== Description ==
oceanpayment AliPay payment  plugin

== Installation ==
1.install the Oceanpayment-AliPay plug-in in the WordPrwss background.
2.Activate oceanpayment AliPay in the plugin menu.
3.Click on woocommerce and select payment settings.
4.Fill in the configuration information.

Configuration	Options/values
Enable/Disable	Configure whether to enable the payment option, unchecked to not enable payment.
Title	        	AliPay
Description	Optional value, description of the payment method in the shop front, usually located below the payment method name.
Account	Provide by Oceanpayment technical support.
Terminal	Provide by Oceanpayment technical support.
SecureCode	Provide by Oceanpayment technical support.
Submiturl	Production:production environment;Sandbox:Test environment.
Pay page Mode	Redirect:Redirect to open payment page;iframe:iframe payment page.

== Screenshots ==
1. This is the administration page of this plugin.
2. Checkout page
3. The payment page