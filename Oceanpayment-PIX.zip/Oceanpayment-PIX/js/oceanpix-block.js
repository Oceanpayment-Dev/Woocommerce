
const oceanpix_settings = window.wc.wcSettings.getSetting( 'oceanpix_data', {} );


const oceanpix_label = window.wp.htmlEntities.decodeEntities( oceanpix_settings.title ) || window.wp.i18n.__( 'Oceanpayment PIX Payment Gateway', 'oceanpayment-pix-gateway' );




const oceanpix_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanpix_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanpix-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanpix_Block_Gateway = {
    name: 'oceanpix',

    label: React.createElement(I, {
        id: "oceanpix",
        title: oceanpix_settings.title,
        icons: oceanpix_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanpix_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanpix_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanpix_label,
    placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-pix-gateway' ),
  /*  supports: {
        features: oceanpix_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanpix_Block_Gateway );