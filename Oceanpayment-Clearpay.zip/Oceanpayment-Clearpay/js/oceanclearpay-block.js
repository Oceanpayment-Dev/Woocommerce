
const oceanclearpay_settings = window.wc.wcSettings.getSetting( 'oceanclearpay_data', {} );


const oceanclearpay_label = window.wp.htmlEntities.decodeEntities( oceanclearpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment Clearpay Payment Gateway', 'oceanpayment-clearpay-gateway' );




const oceanclearpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanclearpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanclearpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanclearpay_Block_Gateway = {
    name: 'oceanclearpay',

    label: React.createElement(I, {
        id: "oceanclearpay",
        title: oceanclearpay_settings.title,
        icons: oceanclearpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanclearpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanclearpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanclearpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-clearpay-gateway' ),
  /*  supports: {
        features: oceanclearpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanclearpay_Block_Gateway );