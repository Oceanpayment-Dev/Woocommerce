
const oceangooglepay_settings = window.wc.wcSettings.getSetting( 'oceangooglepay_data', {} );


const oceangooglepay_label = window.wp.htmlEntities.decodeEntities( oceangooglepay_settings.title ) || window.wp.i18n.__( 'Oceanpayment GooglePay Payment Gateway', 'oceanpayment-googlepay-gateway' );




const oceangooglepay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceangooglepay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceangooglepay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceangooglepay_Block_Gateway = {
    name: 'oceangooglepay',

    label: React.createElement(I, {
        id: "oceangooglepay",
        title: oceangooglepay_settings.title,
        icons: oceangooglepay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceangooglepay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceangooglepay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceangooglepay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-googlepay-gateway' ),
  /*  supports: {
        features: oceangooglepay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceangooglepay_Block_Gateway );