
const oceanzip_settings = window.wc.wcSettings.getSetting( 'oceanzip_data', {} );


const oceanzip_label = window.wp.htmlEntities.decodeEntities( oceanzip_settings.title ) || window.wp.i18n.__( 'Oceanpayment ZIP Payment Gateway', 'oceanpayment-zip-gateway' );




const oceanzip_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanzip_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanzip-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanzip_Block_Gateway = {
    name: 'oceanzip',

    label: React.createElement(I, {
        id: "oceanzip",
        title: oceanzip_settings.title,
        icons: oceanzip_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanzip_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanzip_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanzip_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-zip-gateway' ),
  /*  supports: {
        features: oceanzip_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanzip_Block_Gateway );