=== Oceanpayment CreditCard  One-Page Gateway ===
Contributors: oceanpayment
Tags: payment
Requires at least: 4.0
Tested up to: 6.1
Stable tag: 6.0
Requires PHP: 5.6.20
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

oceanpayment creditcard one-page payment  plugin

== Description ==
oceanpayment creditcard  one-page payment  plugin

== Installation ==
1. Upload the Oceanpayment-creditcard(one-page).zip plug-in in the WordPrwss background.
2. Activate oceanpayment credit card in the plugin menu.
3. Click on woocommerce and select payment settings.
4. Fill in the configuration information.

Configuration	Options/values
Enable/Disable	Configure whether to enable the payment option, unchecked to not enable payment.
Title	        	Credit/Debit Card
Description	Optional value, description of the payment method in the shop front, usually located below the payment method name.
Account		Provide by Oceanpayment technical support.
Terminal		Provide by Oceanpayment technical support.
SecureCode	Provide by Oceanpayment technical support.
Public Key		Provide by Oceanpayment technical support.
Submiturl		Production:production environment;Sandbox:Test environment.
SSL 		https/http, default https.
Payment Language	Supports 24 payment languages, default English (en_US).
Payment Logos	Enable VISA,Mastercard,Maestro,JCB,American Express,VISA(Electron),Diners Club,Discover,UnionPay payment logo.
Write The Logs	True/False.